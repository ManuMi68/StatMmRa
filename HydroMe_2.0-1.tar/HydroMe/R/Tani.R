Tani <-
function(x,thr,ths,alp){
.value<-thr+(ths-thr)*(1+alp*x)*exp(-alp*x)
.value
}
