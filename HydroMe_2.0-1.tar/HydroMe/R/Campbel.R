Campbel <-
function(x,ths,alp,nscal){
.value<-ths*(alp*x)^(-nscal)
.value
}
