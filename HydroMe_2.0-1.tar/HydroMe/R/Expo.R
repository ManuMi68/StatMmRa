Expo <-
function(x,thr,ths,alp){
.value <-thr+ths*exp(-alp*x)
.value
}
