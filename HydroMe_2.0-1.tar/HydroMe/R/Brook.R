Brook <-
function(x,thr,ths,alp,nscal){
.value<-thr+(ths-thr)/(alp*x)^nscal
.value
}
