.onLoad <- function(libname, pkgname) {
  packageStartupMessage("  ** Welcome to measureQ  (version 1.5.0) **")
}
